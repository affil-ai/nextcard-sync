import './assets/service-worker.ts-BKHmGeRA.js';
